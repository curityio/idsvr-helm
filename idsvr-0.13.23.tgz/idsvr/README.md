# Curity Helm

## Introduction

This chart creates Curity on a Kubernetes cluster using the Helm package manager. For more information on Curity and its
capabilities, click [here](https://curity.io).

The release creates the following resources:

* A runtime deployment
* A runtime service

## Installing the Chart

This chart depends on openssl to update the cluster from within a pod. Therefore the chart will only work with images
that have openssl installed.

```console
$ helm repo add curity https://curityio.github.io/idsvr-helm/
$ helm repo update
$ helm install <release-name> curity/idsvr --set <option>=<value>
```

To install the chart, you must provide a password for the admin user or load an existing configuration. Therefore one of
the following must be specified:

* a Secret to load environment variables from
* a Secret containing the configuration that can be mounted
* a password

Take into account that in the latter case your password will be in clear text and may end up in logs. Do use Secrets in
production environment. Check out the [Configuration](#Configuration) chapter below to find the corresponding options.

## Uninstalling the Chart

```console
$ helm delete <release-name>
```

## Tutorial

Tutorials on using the chart and more are available in
the [Curity Resource library](https://curity.io/resources/tutorials/getting-started/setup/install-helm-chart/)

## Configuration

In the table below you can find information about the parameters that are configurable in this chart.

| Parameter                                                 | Description                                                                                                                                                                                                                                          | Default                          |
|-----------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------|
| `replicaCount`                                            | The number of runtime nodes to be deployed                                                                                                                                                                                                           | `1`                              |
| `revisionHistoryLimit`                                    | The number of old ReplicaSets to retain to allow rollback                                                                                                                                                                                            | `10`                             |
| `image.repository`                                        | Image repository                                                                                                                                                                                                                                     | `curity.azurecr.io/curity/idsvr` |
| `image.tag`                                               | Image tag                                                                                                                                                                                                                                            | `11.2`                           |
| `image.pullPolicy`                                        | The policy to be applied in the deployment                                                                                                                                                                                                           | `IfNotPresent`                   |
| `image.pullSecret`                                        | The secret that is used to fetch images from the docker registry                                                                                                                                                                                     | `null`                           |
| `nameOverride`                                            | Override the name release name used in labels and selectors. If left blank it will be `idsvr`                                                                                                                                                        | `""`                             |
| `labels`                                                  | Additional labels that will be added to created resources                                                                                                                                                                                            | `{}`                             |
| `fullnameOverride`                                        | Override the full name used to name resources. If left blank it will be generated by helm with the suffix `-curity`                                                                                                                                  | `""`                             |
| `networkpolicy.enabled`                                   | Enable or disable the network policy which isolates port `curity.admin.service.port` to be accessed only by runtime nodes <sup>[1](#f1)</sup>. Ignored if `curity.admin.enabled=false`                                                               | `true`                           |
| `networkpolicy.apigatewayNamespace`                       | The namespace of an API gateway authorized to call the Admin UI at `curity.adminUiPort` so that the Admin UI is exposed outside of the cluster.                                                                                                      | `default`                        |
| `curity.healthCheckPort`                                  | The port to use for the status server                                                                                                                                                                                                                | `4465`                           |
| `curity.jobsAnnotations`                                  | Extra annotations to add to the batch jobs                                                                                                                                                                                                           | `{}`                             |
| `curity.adminUiPort`                                      | The admin UI and API port. Ignored if `curity.config.uiEnabled=false` and `ingress.admin.enabled=false`                                                                                                                                              | `6749`                           |
| `curity.adminUiHttp`                                      | Controls if admin UI will be on http or https mode after installation if enabled. Ignored if `curity.config.uiEnabled=false`                                                                                                                         | `false`                          |
| `curity.admin.enabled`                                    | Enable or disable deployment of admin pod                                                                                                                                                                                                            | `true`                           |
| `curity.admin.annotations`                                | Extra annotations to add to the admin deployment                                                                                                                                                                                                     | `{}`                             |
| `curity.admin.podLabels`                                  | Extra labels to add to the admin pod                                                                                                                                                                                                                 | `{}`                             |
| `curity.admin.podAnnotations`                             | Extra annotations to add to the admin pod                                                                                                                                                                                                            | `{}`                             |
| `curity.admin.role`                                       | The role of the admin server                                                                                                                                                                                                                         | `admin`                          |
| `curity.admin.distributedService.port`                    | The port used for the distributed service communication                                                                                                                                                                                              | `6790`                           |
| `curity.admin.service.type`                               | The admin service type                                                                                                                                                                                                                               | `ClusterIP`                      |
| `curity.admin.service.port`                               | The admin configuration port                                                                                                                                                                                                                         | `6789`                           |
| `curity.admin.service.annotations`                        | Extra annotations to add to the admin service                                                                                                                                                                                                        | `{}`                             |
| `curity.admin.extraEnv`                                   | Extra environment variables to provide to the admin container                                                                                                                                                                                        | `[]`                             |
| `curity.admin.serviceAccount.name`                        | The name of an existing service account to use on the admin nodes. Defaults to `default` if not specified. <sup>[4](#f4)</sup>                                                                                                                       | `null`                           |
| `curity.admin.initContainers`                             | Definition of initContainers for the admin service                                                                                                                                                                                                   | `[]`                             |
| `curity.admin.extraVolumes`                               | Extra volumes to add to the admin pod                                                                                                                                                                                                                | `[]`                             |
| `curity.admin.extraVolumeMounts`                          | Extra volumes to mount in the admin container                                                                                                                                                                                                        | `[]`                             |
| `curity.admin.livenessProbe.path`                         | LivenessProbe `path` for the admin deployment                                                                                                                                                                                                        | `/`                              |
| `curity.admin.livenessProbe.timeoutSeconds`               | LivenessProbe `timeoutSeconds` for the admin deployment                                                                                                                                                                                              | `1`                              |
| `curity.admin.livenessProbe.failureThreshold`             | LivenessProbe `failureThreshold` for the admin deployment                                                                                                                                                                                            | `3`                              |
| `curity.admin.livenessProbe.periodSeconds`                | LivenessProbe `periodSeconds` for the admin deployment                                                                                                                                                                                               | `10`                             |
| `curity.admin.livenessProbe.initialDelaySeconds`          | The admin `initialDelaySeconds` port                                                                                                                                                                                                                 | `30`                             |
| `curity.admin.readinessProbe.path`                        | ReadinessProbe `path` for the admin deployment                                                                                                                                                                                                       | `/`                              |
| `curity.admin.readinessProbe.timeoutSeconds`              | ReadinessProbe `timeoutSeconds` for the admin deployment                                                                                                                                                                                             | `1`                              |
| `curity.admin.readinessProbe.failureThreshold`            | ReadinessProbe `failureThreshold` for the admin deployment                                                                                                                                                                                           | `3`                              |
| `curity.admin.readinessProbe.successThreshold`            | ReadinessProbe `successThreshold` for the admin deployment                                                                                                                                                                                           | `3`                              |
| `curity.admin.readinessProbe.periodSeconds`               | ReadinessProbe `periodSeconds` for the admin deployment                                                                                                                                                                                              | `10`                             |
| `curity.admin.readinessProbe.initialDelaySeconds`         | ReadinessProbe `initialDelaySeconds` for the admin deployment                                                                                                                                                                                        | `30`                             |
| `curity.admin.logging.level`                              | The logging level of the admin pod                                                                                                                                                                                                                   | `INFO`                           |
| `curity.admin.logging.stdout`                             | Flag to enable/disable extra containers that tail the logs in `var/log` folder                                                                                                                                                                       | `false`                          |
| `curity.admin.logging.logs`                               | Array of the extra containers that will be included in the admin pod                                                                                                                                                                                 | `[]`                             |
| `curity.admin.logging.image`                              | The image that will be used to create the logging containers                                                                                                                                                                                         | `busybox:latest`                 |
| `curity.admin.logging.resources`                          | Resource limits applied in logging containers. When set overrides `logging.resources` settings only on the admin node.                                                                                                                               | `{}`                             |
| `curity.admin.resources`                                  | Resource limits applied in admin deployment. When set overrides `resources` settings only on the admin node.                                                                                                                                         | `{}`                             |
| `curity.admin.nodeSelector`                               | Node selector for the admin deployment. When set overrides `nodeSelector` settings only on the admin node.                                                                                                                                           | `{}`                             |
| `curity.admin.tolerations`                                | Tolerations for the admin deployment. When set overrides `tolerations` settings only on the admin node.                                                                                                                                              | `[]`                             |
| `curity.admin.affinity`                                   | Affinity for the admin deployment. When set overrides `affinity` settings only on the admin node.                                                                                                                                                    | `{}`                             |
| `curity.admin.securityContext.runAsUser`                  | The user the container in the pod will run as.                                                                                                                                                                                                       | `10001`                          |
| `curity.admin.securityContext.runAsGroup`                 | The group the container in the pod will run as.                                                                                                                                                                                                      | `10000`                          |
| `curity.admin.securityContext.runAsUser`                  | The file system group for mounted volumes.                                                                                                                                                                                                           | `10000`                          |
| `curity.admin.containerSecurityContext`                   | Container-level security context applied to all containers in the admin Deployment, including logging sidecars.                                                                                                                                      | `{}`                             |
| `curity.runtime.role`                                     | The role of the runtime servers                                                                                                                                                                                                                      | `default`                        |
| `curity.runtime.annotations`                              | Extra annotations to add to the runtime deployment                                                                                                                                                                                                   | `default`                        |
| `curity.runtime.podLabels`                                | Extra labels to add to the runtime pod                                                                                                                                                                                                               | `{}`                             |
| `curity.runtime.podAnnotations`                           | Extra annotations to add to the runtime pod                                                                                                                                                                                                          | `{}`                             |
| `curity.podDisruptionBudget.minAvailable`                 | Number of pods from that set that must still be available after the eviction, can be either an absolute number or a percentage.                                                                                                                      | ``                               |
| `curity.podDisruptionBudget.maxUnavailable`               | Number of runtime pods that can be unavailable after the eviction, can be either an absolute number or a percentage.                                                                                                                                 | ``                               |
| `curity.runtime.initContainers`                           | Definition of initContainers for the runtime service                                                                                                                                                                                                 | `[]`                             |
| `curity.runtime.extraVolumes`                             | Extra volumes to add to the runtime pod                                                                                                                                                                                                              | `[]`                             |
| `curity.runtime.extraVolumeMounts`                        | Extra volumes to mount in the runtime container                                                                                                                                                                                                      | `[]`                             |
| `curity.runtime.service.type`                             | The runtime service type                                                                                                                                                                                                                             | `ClusterIP`                      |
| `curity.runtime.service.port`                             | The runtime service port                                                                                                                                                                                                                             | `8443`                           |
| `curity.runtime.service.annotations`                      | Extra annotations to add to the runtime service                                                                                                                                                                                                      | `{}`                             |
| `curity.runtime.deployment.port`                          | The runtime deployment port                                                                                                                                                                                                                          | `8443`                           |
| `curity.runtime.extraEnv`                                 | Extra environment variables to provide to the runtime container                                                                                                                                                                                      | `[]`                             |
| `curity.runtime.serviceAccount.name`                      | The name of an existing service account to use on the runtime nodes. Defaults to `default` if not specified.                                                                                                                                         | `null`                           |
| `curity.runtime.livenessProbe.path`                       | LivenessProbe `path` for the runtime deployment                                                                                                                                                                                                      | `/`                              |
| `curity.runtime.livenessProbe.timeoutSeconds`             | LivenessProbe `timeoutSeconds` for the runtime deployment                                                                                                                                                                                            | `1`                              |
| `curity.runtime.livenessProbe.failureThreshold`           | LivenessProbe `failureThreshold` for the runtime deployment                                                                                                                                                                                          | `3`                              |
| `curity.runtime.livenessProbe.periodSeconds`              | LivenessProbe `periodSeconds` for the runtime deployment                                                                                                                                                                                             | `10`                             |
| `curity.runtime.livenessProbe.initialDelaySeconds`        | The admin `initialDelaySeconds` port                                                                                                                                                                                                                 | `30`                             |
| `curity.runtime.readinessProbe.path`                      | ReadinessProbe `path` for the runtime deployment                                                                                                                                                                                                     | `/`                              |
| `curity.runtime.readinessProbe.timeoutSeconds`            | ReadinessProbe `timeoutSeconds` for the runtime deployment                                                                                                                                                                                           | `1`                              |
| `curity.runtime.readinessProbe.failureThreshold`          | ReadinessProbe `failureThreshold` for the runtime deployment                                                                                                                                                                                         | `3`                              |
| `curity.runtime.readinessProbe.successThreshold`          | ReadinessProbe `successThreshold` for the runtime deployment                                                                                                                                                                                         | `3`                              |
| `curity.runtime.readinessProbe.periodSeconds`             | ReadinessProbe `periodSeconds` for the runtime deployment                                                                                                                                                                                            | `10`                             |
| `curity.runtime.readinessProbe.initialDelaySeconds`       | ReadinessProbe `initialDelaySeconds` for the runtime deployment                                                                                                                                                                                      | `30`                             |
| `curity.runtime.logging.level`                            | The logging level of the runtime pod                                                                                                                                                                                                                 | `INFO`                           |
| `curity.runtime.logging.stdout`                           | Flag to enable/disable extra containers that tail the logs in `var/log` folder.                                                                                                                                                                      | `false`                          |
| `curity.runtime.logging.logs`                             | Array of the extra containers that will be included in the runtime pods                                                                                                                                                                              | `[]`                             |
| `curity.runtime.logging.image`                            | The image that will be used to create the logging containers                                                                                                                                                                                         | `busybox:latest`                 |
| `curity.runtime.logging.resources`                        | Resource limits applied in logging containers. When set overrides `logging.resources` settings only on the runtime nodes.                                                                                                                            | `{}`                             |
| `curity.runtime.resources`                                | Resource limits applied in runtime deployment. When set overrides `resources` settings only on the runtime nodes.                                                                                                                                    | `{}`                             |
| `curity.runtime.nodeSelector`                             | Node selector for the runtime deployment. When set overrides `nodeSelector` settings only on the runtime nodes.                                                                                                                                      | `{}`                             |
| `curity.runtime.tolerations`                              | Tolerations for the runtime deployment. When set overrides `tolerations` settings only on the runtime nodes.                                                                                                                                         | `[]`                             |
| `curity.runtime.affinity`                                 | Affinity for the runtime deployment. When set overrides `affinity` settings only on the runtime nodes.                                                                                                                                               | `{}`                             |
| `curity.runtime.lifecycle`                                | These options include settings for startup, shutdown, and other lifecycle events.                                                                                                                                                                    | `[]`                             |
| `curity.runtime.terminationGracePeriodSeconds`            | Sets the termination grace period for runtime pods spawned by the Kubernetes Deployment.                                                                                                                                                             | `30`                             |
| `curity.runtime.affinity`                                 | Affinity for runtime pod assignment.                                                                                                                                                                                                                 | `{}`                             |
| `curity.runtime.topologySpreadConstraints`                | Topology spread constraints for runtime pod assignment (requires Kubernetes >= 1.19).                                                                                                                                                                | `[]`                             |
| `curity.runtime.securityContext.runAsUser`                | The user the container in the pod will run as.                                                                                                                                                                                                       | `10001`                          |
| `curity.runtime.securityContext.runAsGroup`               | The group the container in the pod will run as.                                                                                                                                                                                                      | `10000`                          |
| `curity.runtime.securityContext.runAsUser`                | The file system group for mounted volumes.                                                                                                                                                                                                           | `10000`                          |
| `curity.runtime.containerSecurityContext`                 | Container-level security context applied to all containers in the runtime Deployment, including logging sidecars.                                                                                                                                    | `{}`                             |
| `curity.clusterConfJob.containerSecurityContext`          | Container-level security context applied to the cluster configuration Job container.                                                                                                                                                                 | `{}`                             |
| `curity.convertKeystoreConfJob.containerSecurityContext`  | Container-level security context applied to the keystore conversion Job container.                                                                                                                                                                   | `{}`                             |
| `curity.dbSchemaManagementJob.enabled`                    | Flag to enable/disable the pre-install/pre-upgrade Job that runs `idsvr -I` to create or update the Curity database schema. When `true`, either `jdbcConnectionString` or a secret in `environmentVariableSecrets` providing `JDBC_URL` must be set. | `false`                          |
| `curity.dbSchemaManagementJob.jdbcConnectionString`       | The JDBC URL the Job uses to connect to the database. Rendered into the `JDBC_URL` env var. Leave unset and provide it via `environmentVariableSecrets` to keep it out of the rendered manifest.                                                     | `null`                           |
| `curity.dbSchemaManagementJob.jdbcUsername`               | Username for the database connection. Rendered into the `JDBC_USERNAME` env var. Omit if the connection string already encodes credentials or if authentication is handled out-of-band.                                                              | `null`                           |
| `curity.dbSchemaManagementJob.jdbcPassword`               | Password for the database connection. Rendered into the `JDBC_PASSWORD` env var. Prefer supplying this through `environmentVariableSecrets` rather than inline.                                                                                      | `null`                           |
| `curity.dbSchemaManagementJob.environmentVariableSecrets` | Array of Secret names whose keys are mounted as environment variables on the Job (via `envFrom`). Use this to inject `JDBC_URL`, `JDBC_USERNAME`, or `JDBC_PASSWORD` from Secrets instead of plain values.                                           | `[]`                             |
| `curity.dbSchemaManagementJob.serviceAccount.name`        | Service account used by the Job pod. The Job does not need to call the Kubernetes API.                                                                                                                                                               | `default`                        |
| `curity.dbSchemaManagementJob.resources`                  | Resource requests and limits applied to the Job container.                                                                                                                                                                                           | `{}`                             |
| `curity.dbSchemaManagementJob.securityContext`            | Pod-level securityContext applied to the Job.                                                                                                                                                                                                        | `{}`                             |
| `curity.dbSchemaManagementJob.containerSecurityContext`   | Container-level security context applied to the database schema management Job container.                                                                                                                                                            | `{}`                             |
| `curity.config.disableClusterConfigJob`                   | Flag to enable/disable the creation of the Job that generates the cluster xml. When set to `true` clustering configuration should be provided in other means.                                                                                        | `false`                          |
| `curity.config.uiEnabled`                                 | Flag to enable/disable the service for Admin UI and Admin REST API, ignored if `ingress.admin.enabled=true` or `curity.admin.enabled=false`                                                                                                          | `false`                          |
| `curity.config.password`                                  | The administrator password. Required if `curity.config.skipInstall` is `true` or `curity.config.environmentVariableSecrets` and `curity.config.configuration`is not set                                                                              | `null`                           |
| `curity.config.skipInstall`                               | If set to `true` the installer script will not run<sup>[3](#f3)</sup>                                                                                                                                                                                | `false`                          |
| `curity.config.encryptionKey`                             | The configuration encryption key                                                                                                                                                                                                                     | `null`                           |
| `curity.config.environmentVariableSecret`                 | *DEPRECATED* The data from this Secret will be mounted as environment variables                                                                                                                                                                      | `null`                           |
| `curity.config.environmentVariableSecrets`                | The data from this array of Secret names will be mounted as environment variables                                                                                                                                                                    | `null`                           |
| `curity.config.environmentVariableConfigMaps`             | The data from this array of ConfigMap names will be mounted as environment variables                                                                                                                                                                 | `null`                           |
| `curity.config.configurationSecret`                       | *DEPRECATED* The Secret containing configuration which is mounted as a volume                                                                                                                                                                        | `null`                           |
| `curity.config.configurationSecretItemName`               | *DEPRECATED* The `curity.config.configurationSecret`'s item name, required if the Secret is set.                                                                                                                                                     | `null`                           |
| `curity.config.configurationConfigMap`                    | *DEPRECATED* The ConfigMap containing configuration which is mounted as a volume                                                                                                                                                                     | `null`                           |
| `curity.config.configurationConfigMapItemName`            | *DEPRECATED* The `curity.config.configurationConfigMap`'s item name, required if the ConfigMap is set.                                                                                                                                               | `null`                           |
| `curity.config.configuration`                             | The array of Configmap and Secret configuration items are mounted as a volume                                                                                                                                                                        | `[]`                             |
| `curity.config.postCommitScripts`                         | The array of post-commit scripts are mounted as a volume                                                                                                                                                                                             | `[]`                             |
| `curity.config.convertKeystore`                           | The array of secrets containing tls certificates that will be converted to Curity format                                                                                                                                                             | `[]`                             |
| `curity.config.backup`                                    | If `true`, the configuration will be backed up in a secret in each commit, ignored if `curity.admin.enabled=false`                                                                                                                                   | `false`                          |
| `curity.config.persistentConfigVolume.enabled`            | If `true` a persisted volume will be mounted in the admin node to persist config during deployment upgrades, ignored if `curity.admin.enabled=false`                                                                                                 | `false`                          |
| `curity.config.persistentConfigVolume.storageClass`       | The `StorageClass` of the volume                                                                                                                                                                                                                     | `default`                        | 
| `curity.config.persistentConfigVolume.existingClaim`      | If set, an existing persisted volume claim will be used instead of a new one beeing generated.                                                                                                                                                       | `""`                             |
| `curity.config.persistentConfigVolume.accessMode`         | The access mode of the volume                                                                                                                                                                                                                        | `ReadWriteOnce`                  |
| `curity.config.persistentConfigVolume.size`               | The size of the persisted volume                                                                                                                                                                                                                     | `800Mi`                          |
| `ingress.annotations`                                     | Extra annotations for the Ingress resource                                                                                                                                                                                                           | `{}`                             |
| `ingress.runtime.enabled`                                 | Flag to enable/disable the Ingress resource for runtime nodes                                                                                                                                                                                        | `false`                          |
| `ingress.runtime.annotations`                             | Extra annotations for the Ingress resource for the runtime nodes, overrides `ingress.annotations` if set                                                                                                                                             | `{}`                             |
| `ingress.runtime.host`                                    | Hostname of the runtime servers (used by the Ingress resource)                                                                                                                                                                                       | `curity.local`                   |
| `ingress.runtime.tlsHost`                                 | Hostname of the runtime servers (used by the Ingress resource) to be able to use wildcard as host                                                                                                                                                    | ``                               |
| `ingress.runtime.paths`                                   | Paths of the runtime servers that can be accessed externally                                                                                                                                                                                         | `{/}`<sup>[2](#f2)</sup>         |
| `ingress.runtime.pathType`                                | PathTpe for the paths defined in `ingress.runtime.paths`                                                                                                                                                                                             | `ImplementationSpecific`         |
| `ingress.runtime.secretName`                              | Secret which contains the tls cert and key for the runtime TLS connection. If not set, the Ingress will be configured for HTTP                                                                                                                       | `null`                           |
| `ingress.runtime.tlsEnabled`                              | Enables TLS for the ingress when set to `true`. **NOTE:** if set to `false` TLS will still be configured if `ingress.runtime.secretName` is set, this is to keep the old logic and avoid breaking changes                                            | `false`                          |
| `ingress.admin.enabled`                                   | Flag to enable/disable an Ingress resource for the admin node, ignored if `curity.admin.enabled=false`                                                                                                                                               | `false`                          |
| `ingress.admin.annotations`                               | Extra annotations for the Ingress resource for the admin node, overrides `ingress.annotations` if set                                                                                                                                                | `{}`                             |
| `ingress.admin.host`                                      | Hostname for the admin server (used by the Ingress resource)                                                                                                                                                                                         | `curity-admin.local`             |
| `ingress.admin.tlsHost`                                   | Hostname for the admin server (used by the Ingress resource) to be able to use wildcard as host                                                                                                                                                      | ``                               |
| `ingress.admin.secretName`                                | Secret which contains the tls cert and key for the runtime TLS connection. If not set, the Ingress resource will be configured for HTTP                                                                                                              | `null`                           |
| `ingress.admin.tlsEnabled`                                | Enables TLS for the ingress when set to `true`. **NOTE:** if set to `false` TLS will still be configured if `ingress.runtime.secretName` is set, this is to keep the old logic and avoid breaking changes                                            | `false`                          |
| `ingress.admin.paths`                                     | Paths of the admin node that can be accessed externally                                                                                                                                                                                              | `{/}`<sup>[2](#f2)</sup>         |
| `ingress.admin.pathType`                                  | PathTpe for the paths defined in `ingress.admin.paths`                                                                                                                                                                                               | `ImplementationSpecific`         |
| `resources`                                               | Resource limits applied in admin and runtime deployments                                                                                                                                                                                             | `{}`                             |
| `logging.resources`                                       | Resource limits applied in admin and runtime deployments logging containers                                                                                                                                                                          | `{}`                             |
| `autoscaling.enabled`                                     |                                                                                                                                                                                                                                                      | `false`                          |
| `autoscaling.minReplicas`                                 | Minimum number of replicas                                                                                                                                                                                                                           | `1`                              |
| `autoscaling.maxReplicas`                                 | Maximum number of replicas                                                                                                                                                                                                                           | `10`                             |
| `autoscaling.targetCPUUtilizationPercentage`              | CPU Utilization persentage that triggers scaling up                                                                                                                                                                                                  | `80`                             |
| `autoscaling.targetMemoryUtilizationPercentage`           | Memory Utilization persentage that triggers scaling up                                                                                                                                                                                               | ``                               |
| `autoscaling.customMetrics`                               | Custom metric definition                                                                                                                                                                                                                             | `[]`                             |
| `postHook.enabled`                                        | Enable post hook e.g. for to post message on slack or other                                                                                                                                                                                          | `false`                          |
| `postHook.annotaions`                                     | Extra annotations to add to the post hook                                                                                                                                                                                                            | `{}`                             |
| `postHook.image`                                          | Specifies which image to use for post hook container                                                                                                                                                                                                 | `curlimages/curl:latest`         |
| `postHook.args`                                           | List of arguments. Default command is _/bin/sh_                                                                                                                                                                                                      | `[]`                             |
| `postHook.command`                                        | The command for the posthook container                                                                                                                                                                                                               | `/bin/sh`                        |
| `postHook.extraEnv`                                       | Extra environment variables to provide to the posthook container                                                                                                                                                                                     | `[]`                             |
| `postHook.containerSecurityContext`                       | Container-level security context applied to the post hook container.                                                                                                                                                                                 | `{}`                             |
| `nodeSelector`                                            | Default node selector applied to all deployments and jobs. Can be overridden per deployment with `curity.admin.nodeSelector` and `curity.runtime.nodeSelector`.                                                                                      | `{}`                             |
| `tolerations`                                             | Default tolerations applied to all deployments and jobs. Can be overridden per deployment with `curity.admin.tolerations` and `curity.runtime.tolerations`.                                                                                          | `{}`                             |
| `affinity`                                                | Default affinity applied to all deployments and jobs. Can be overridden per deployment with `curity.admin.affinity` and `curity.runtime.affinity`.                                                                                                   | `{}`                             |
| `ingress.ingressClassName`                                | IngressClassName is the name of an IngressClass cluster resource. Ingress controller use this field to know whether they should be serving this Ingress resource.                                                                                    | `null`                           |

<b id="f1">1</b> The network policy within the cluster will not have any affect unless there is a network policy
provider that can enforce network policies. Check out kubernetes official documentation for more guidance on how to
install network
providers: [Install Network Policy Provider - Kubernetes](https://kubernetes.io/docs/tasks/administer-cluster/network-policy-provider/)

<b id="f2">2</b> When using Helm's `--set` option, lists can be expressed by enclosing values in `{` and `}`. For
example, `--set ingress.runtime.paths="{/foo, /bar}"` translates to:

```
paths:
- /foo
- /bar
```

<b id="f3">3</b> The `unattendedinstall` script runs by default on the admin node if an admin `PASSWORD` is set, either
by the value or some other environment variable. The installer creates default keys and enables the Admin UI so this
configuration option shall be used if that config is either not necessary or loaded in some other way (i.e using
`curity.config.configuration` or embedded in the docker image used).

<b id="f4">5</b> If `curity.config.backup` is enabled, the assigned service account must have access to update secrets.

## Examples

### Quickstart

To get started and test this helm chart run the following commands:

```console
$ helm repo add curity https://curityio.github.io/idsvr-helm/
$ helm repo update
$ helm install <release-name> curity/idsvr --set curity.config.password=<admin_user_password>
```

## Database schema management

When Curity is configured with a JDBC data source, the database schema can be managed by the helm chart. The chart can
run a one-shot Job that invokes `idsvr -I` against the configured database to create or update the schema. The Job runs
as a `pre-install,pre-upgrade` hook and exits as soon as schema management completes.

To enable it, set `curity.dbSchemaManagementJob.enabled` to `true` and provide a JDBC URL. The simplest form:

```shell
helm install <release-name> curity/idsvr \
  --set curity.config.password=<admin_password> \
  --set curity.dbSchemaManagementJob.enabled=true \
  --set curity.dbSchemaManagementJob.jdbcConnectionString=<jdbc-url> \
  --set curity.dbSchemaManagementJob.jdbcUsername=<db-user> \
  --set curity.dbSchemaManagementJob.jdbcPassword=<db-password>
```

If `enabled` is `true` but no connection string is provided (neither inline nor via a Secret), `helm install`/`upgrade`
aborts at render time with an error.

### Providing connection details via a Secret

Inline values land in the rendered manifest in plain text. To keep credentials out of release manifests and Helm
history, put `JDBC_URL`, `JDBC_USERNAME`, and `JDBC_PASSWORD` in a Kubernetes Secret and reference it in
`environmentVariableSecrets`:

```shell
kubectl create secret generic idsvr-db-credentials \
  --from-literal=JDBC_URL='jdbc:postgresql://db.example.com:5432/idsvr' \
  --from-literal=JDBC_USERNAME='<username>' \
  --from-literal=JDBC_PASSWORD='<password>'
```

```yaml
curity:
  dbSchemaManagementJob:
    enabled: true
    environmentVariableSecrets:
      - idsvr-db-credentials
```

You can mix the two: inline values from `jdbcConnectionString` / `jdbcUsername` / `jdbcPassword` are emitted as `env:`
entries and will take precedence over the same keys coming from `envFrom:` Secrets per Kubernetes semantics.

### Inspecting Job output

The Job sets `ttlSecondsAfterFinished: 3600`, so it stays around for an hour after completion. To see what `idsvr -I`
did:

```shell
kubectl logs -l job-name=<release-name>-<revision>-db-mgmt-job -n <namespace>
```

After the TTL expires the Job and its pod are garbage collected by Kubernetes.

## Using configuration Backup

In order for the configuration to be backed up in each commit, the flag`curity.config.backup` must be set to `true`.

When this is the case, a script is mounted into the admin node which runs in each commit and dumps the full
configuration
(minus the clustering configuration which is handled by this chart) and adds it to a secret which by default has the
name`{{ include "curity.fullname" . }}-config-backup`. The key for the configuration is `<DATE>-<TRANSACTION_ID>.xml`.

So, in order to update your deployment and use a previous backup of the configuration, you need to reference it in
`curity.config.configuration`:

```shell script
curity:
    config:
        configuration:
          - secretRef:
            name: `{{ include "curity.fullname" . }}-config-backup`
            items:
            - key: <DATE>-<TRANSACTION_ID>.xml
              path: config-backup.xml
```

```shell script
helm upgrade <release-name> curity/idsvr -f myValues.xml
```

## Enabling the persistent configuration volume

It is possible to set the `curity.config.persistentConfigVolume.enabled` which will create a `PersistedVolumeClaim`
using the defined `storageClass`, `accessMode` and `size`.
The volume will be mounted to the admin Pod under `/opt/idsvr/var/cdb`.

When this is enabled, the cluster keys are not rotated between deployment upgrades. Instead only a single key is
generated during installation and will be kept for the lifetime of the deployment.
Also, any configuration that is stored in `/opt/idsvr/etc/init` either by `curity.config.configuration` or by included
files in the image will be ignored for subsequent upgrades except the first installation.

Although enabling this setting is perfect for experimenting with the Curity Identity Server, it is not something that we
suggest to be used in production as it can lead to issues that are difficult to overcome.

## Sending all logs to stdout

If `curity.admin.logging.stdout` is `true`, the Chart will add extra containers in the pods, that will tail any
additional log files defined in `curity.admin.logging.logs` and pipe them to stdout. The same applies
for `curity.runtime.logging.stdout`.

## Mount configuration files from configmaps and secrets

Use the `curity.config.configuration` to mount several files from configmaps and secrets into `etc/init` folder.

Example:

```
curity:
  config:
    configuration:
      - configMapRef:
          name: cfg-configmap-name
          items:
            - key: item-1
              path: item-1.xml
            - key: item-2
              path: item-2.xml
      - secretRef:
          name: cfg-secret
          items:
            - key: scrt-1
              path: scrt-1.xml
            - key: scrt-2
              path: scrt-2.xml
      - secretRef:
          name: cfg-secret-2
          items:
            - key: cfg
              path: configuration.xml
```

## Mount custom script from postCommit

Use the `curity.config.configuration` to mount several files from postCommit into `post-commit-scripts/` folder.

Example:

```
curity:
  config:
    configuration:
     - secretRef:
         name: curity-idsvr-config-backup
         items:
           - key: latest.xml
             path: latest.xml
     - postCommit:
        - name: custom-script-name-1
          script: |
              #!/bin/bash
     - postCommit:
        - name: custom-script-name-2
          script: |
              #!/bin/bash
              echo "Run cutom script"
```

## Post hook container

Enable the post hook `postHook.enabled=true` to start a post hook container.

Example: Post message to slack.

```
    postHook:
      enabled: true
      image: nexus.hh.atg.se:17000/curlimages/curl:7.79.1
      args:
        - -ec
        - curl -X POST --data-urlencode 'payload={"username":"HelmRelease","text":"`$(APP_NAME)`, version `$(APP_VERSION)` (`$(CHART_NAME)` ) in `$(RELEASE_NAMESPACE)` has been deployed"}' "$(SLACK_WEBHOOK_URL)"
      extraEnv:
        - name: SLACK_WEBHOOK_URL
          valueFrom:
            secretKeyRef:
              key: SLACK_WEBHOOK_URL
              name: curity-idsvr-secret
```

Built in variables are that are exposed as environment variables in post hook container :

- `APP_NAME` - Curity fullname
- `APP_VERSION` - Image tag
- `CHART_NAME` - Chart name and version
- `RELEASE_NAMESPACE` - Target namespace

## More Information

Please visit [curity.io](https://curity.io/)for more information about the Curity Identity Server.

Copyright (C) 2020 Curity AB.

